package com.waa.phase1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
